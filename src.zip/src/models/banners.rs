use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Banner {
    pub id: String, // ULID dari bytea
    pub image_url: String,
    pub click_url: Option<String>,
    pub start_date: DateTime<Utc>,
    pub end_date: Option<DateTime<Utc>>,
    pub deleted_at: Option<DateTime<Utc>>,
    pub event_id: Option<String>, // ULID dari bytea
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

// Request/Response khusus bila perlu (opsional)
#[derive(Debug, Deserialize)]
pub struct ListBannersQuery {
    pub event_id: Option<String>, // filter berdasarkan event
}
