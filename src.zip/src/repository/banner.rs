use anyhow::Result;
use async_trait::async_trait;
use chrono::{DateTime, Utc};
use deadpool_postgres::Pool;
use tokio_postgres::Row;

use crate::{
    models::banners::Banner,
    utils::ulid::{bin_to_ulid, id_to_vec},
};

#[async_trait]
pub trait BannerRepository: Send + Sync {
    /// Ambil banner yang aktif pada waktu `now`.
    /// Aktif = deleted_at IS NULL, start_date <= now, dan (end_date IS NULL OR end_date >= now)
    async fn list_active(&self, now: DateTime<Utc>, event_id: Option<&str>) -> Result<Vec<Banner>>;

    /// Opsional: ambil satu banner berdasarkan ID
    async fn find_by_id(&self, id: &str) -> Result<Option<Banner>>;
}

const BANNER_COLS: &str = r#"
    id, image_url, click_url, start_date, end_date, deleted_at,
    event_id, created_at, updated_at
"#;

fn row_to_banner(row: &Row) -> Result<Banner> {
    let id_bytes: Vec<u8> = row.try_get("id")?;
    let event_bytes: Option<Vec<u8>> = row.try_get("event_id")?;
    Ok(Banner {
        id: bin_to_ulid(id_bytes)?,
        image_url: row.try_get("image_url")?,
        click_url: row.try_get("click_url")?,
        start_date: row.try_get("start_date")?,
        end_date: row.try_get("end_date")?,
        deleted_at: row.try_get("deleted_at")?,
        event_id: event_bytes.map(bin_to_ulid).transpose()?,
        created_at: row.try_get("created_at")?,
        updated_at: row.try_get("updated_at")?,
    })
}

pub struct PgBannerRepository {
    pool: Pool,
}

impl PgBannerRepository {
    pub fn new(pool: Pool) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl BannerRepository for PgBannerRepository {
    async fn list_active(&self, now: DateTime<Utc>, event_id: Option<&str>) -> Result<Vec<Banner>> {
        let mut sql = format!(
            "SELECT {} FROM public.banners
             WHERE deleted_at IS NULL
               AND start_date <= $1
               AND (end_date IS NULL OR end_date >= $1)",
            BANNER_COLS
        );

        let eid_bytes_opt = match event_id {
            Some(eid) => Some(id_to_vec(eid)?),
            None => None,
        };

        let mut params: Vec<&(dyn tokio_postgres::types::ToSql + Sync)> = vec![&now];
        if let Some(ref bytes) = eid_bytes_opt {
            sql.push_str(" AND event_id = $2");
            params.push(bytes);
        }

        sql.push_str(" ORDER BY start_date DESC, created_at DESC");

        let client = self.pool.get().await?;
        let rows = client.query(&sql, &params).await?;
        rows.iter().map(row_to_banner).collect()
    }

    async fn find_by_id(&self, id: &str) -> Result<Option<Banner>> {
        let id_bytes = id_to_vec(id)?;
        let client = self.pool.get().await?;
        let row = client
            .query_opt(
                &format!("SELECT {} FROM public.banners WHERE id = $1", BANNER_COLS),
                &[&id_bytes],
            )
            .await?;
        row.map(|r| row_to_banner(&r)).transpose()
    }
}
