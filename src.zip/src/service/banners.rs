use anyhow::Result;
use chrono::Utc;
use std::sync::Arc;

use crate::models::banners::Banner;
use crate::repository::banner::BannerRepository;

// Generic struct dengan trait bound
pub struct BannerService<R: BannerRepository> {
    repo: Arc<R>,
}

impl<R: BannerRepository> BannerService<R> {
    pub fn new(repo: Arc<R>) -> Self {
        Self { repo }
    }

    /// Daftar banner yang sedang aktif saat ini
    pub async fn list_active(&self, event_id: Option<&str>) -> Result<Vec<Banner>> {
        let now = Utc::now();
        self.repo.list_active(now, event_id).await
    }

    /// Opsional: detail banner by id
    pub async fn get_by_id(&self, id: &str) -> Result<Option<Banner>> {
        self.repo.find_by_id(id).await
    }
}
