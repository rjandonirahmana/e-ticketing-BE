use crate::state::AppState;
use axum::{
    Json,
    extract::{Query, State},
};
use serde::Deserialize;
use std::sync::Arc;

use crate::models::banners::Banner;
use crate::utils::error::AppResult;

#[derive(Debug, Deserialize)]
pub struct ListBannersQuery {
    pub event_id: Option<String>,
}

pub async fn list_active(
    State(svc): State<Arc<AppState>>,
    Query(q): Query<ListBannersQuery>,
) -> AppResult<Json<Vec<Banner>>> {
    let banners = svc.banner_svc.list_active(q.event_id.as_deref()).await?;
    Ok(Json(banners))
}
