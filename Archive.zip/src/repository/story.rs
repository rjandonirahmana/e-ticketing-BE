//! repository/story.rs
//!
//! Akses data untuk tabel `stories`, `story_views`, dan `user_subscriptions`.

use anyhow::{Context, Result};
use async_trait::async_trait;
use deadpool_postgres::Pool;
use serde_json::Value as JsonValue;
use tokio_postgres::Row;

use super::db::get_conn;
use crate::models::stories::{Story, StoryGroupResponse, StoryItemResponse, SubscriptionActivation, UserSubscription};
use crate::web::models::PendingSubOrder;
use crate::utils::ulid::{bin_to_ulid, bin_to_ulid_opt, id_to_vec, new_ulid, ulid_to_vec};

// ── Row mappers ───────────────────────────────────────────────────────────────

fn row_to_story(row: &Row) -> Result<Story> {
    let id_bytes: Vec<u8> = row.try_get("id")?;
    let user_bytes: Vec<u8> = row.try_get("user_id")?;
    let event_bytes: Option<Vec<u8>> = row.try_get("event_id")?;

    let overlays_json: Option<serde_json::Value> = row.try_get("overlays")?;
    let overlays: Vec<JsonValue> = match overlays_json {
        Some(serde_json::Value::Array(a)) => a,
        _ => vec![],
    };

    Ok(Story {
        id: bin_to_ulid(id_bytes)?,
        user_id: bin_to_ulid(user_bytes)?,
        media_url: row.try_get("media_url")?,
        media_type: row.try_get("media_type")?,
        filter: row.try_get("filter")?,
        overlays,
        event_id: bin_to_ulid_opt(event_bytes)?,
        event_slug: row.try_get("event_slug")?,
        event_title: row.try_get("event_title")?,
        created_at: row.try_get("created_at")?,
        expires_at: row.try_get("expires_at")?,
    })
}

fn row_to_subscription(row: &Row) -> Result<UserSubscription> {
    let id_bytes: Vec<u8> = row.try_get("id")?;
    let user_bytes: Vec<u8> = row.try_get("user_id")?;
    Ok(UserSubscription {
        id: bin_to_ulid(id_bytes)?,
        user_id: bin_to_ulid(user_bytes)?,
        plan: row.try_get("plan")?,
        started_at: row.try_get("started_at")?,
        expires_at: row.try_get("expires_at")?,
        is_active: row.try_get("is_active")?,
        created_at: row.try_get("created_at")?,
    })
}

/// Map satu row (query list_groups / list_groups_public / list_user_groups_paged —
/// kolomnya identik) menjadi StoryItemResponse.
fn row_to_story_item(row: &Row) -> Result<StoryItemResponse> {
    let id_bytes: Vec<u8> = row.try_get("id")?;
    let user_bytes: Vec<u8> = row.try_get("user_id")?;
    let event_bytes: Option<Vec<u8>> = row.try_get("event_id")?;

    let overlays_json: Option<serde_json::Value> = row.try_get("overlays")?;
    let overlays: Vec<JsonValue> = match overlays_json {
        Some(serde_json::Value::Array(a)) => a,
        _ => vec![],
    };

    Ok(StoryItemResponse {
        id: bin_to_ulid(id_bytes)?,
        user_id: bin_to_ulid(user_bytes)?,
        username: row.try_get("username")?,
        avatar_url: row.try_get("avatar_url")?,
        media_url: row.try_get("media_url")?,
        media_type: row.try_get("media_type")?,
        filter: row.try_get("filter")?,
        overlays,
        created_at: row.try_get("created_at")?,
        expires_at: row.try_get("expires_at")?,
        viewed: row.try_get("viewed")?,
        event_id: bin_to_ulid_opt(event_bytes)?,
        event_slug: row.try_get("event_slug")?,
        event_title: row.try_get("event_title")?,
    })
}

/// Group rows hasil query list_groups/list_groups_public per user_id
/// (urutan baris sudah benar dari ORDER BY di SQL).
fn rows_to_story_groups(rows: &[Row]) -> Result<Vec<StoryGroupResponse>> {
    let mut groups: Vec<StoryGroupResponse> = Vec::new();
    for row in rows {
        let item = row_to_story_item(row)?;

        if let Some(g) = groups.iter_mut().find(|g| g.user_id == item.user_id) {
            g.stories.push(item);
        } else {
            groups.push(StoryGroupResponse {
                user_id: item.user_id.clone(),
                username: item.username.clone(),
                avatar_url: item.avatar_url.clone(),
                stories: vec![item],
            });
        }
    }
    Ok(groups)
}

// ── Trait ─────────────────────────────────────────────────────────────────────

#[async_trait]
pub trait StoryRepository: Send + Sync {
    /// Cek apakah user punya active premium subscription.
    async fn is_premium(&self, user_id: &str) -> Result<bool>;

    /// Hitung jumlah story yang user buat hari ini (UTC).
    async fn count_today(&self, user_id: &str) -> Result<i64>;

    /// Insert story baru, return record lengkap.
    async fn create(
        &self,
        user_id: &str,
        media_url: &str,
        media_type: &str,
        filter: Option<&str>,
        overlays: &[JsonValue],
        event_id: Option<&str>,
        event_slug: Option<&str>,
        event_title: Option<&str>,
    ) -> Result<Story>;

    /// Ambil semua story aktif (belum expired), dikelompokkan per user.
    /// Story milik `viewer_id` ditaruh di posisi pertama.
    async fn list_groups(&self, viewer_id: &str) -> Result<Vec<StoryGroupResponse>>;

    /// Versi publik (viewer anonim / belum login): semua story aktif tanpa
    /// status `viewed` per-user. Dipakai agar pengunjung tetap bisa melihat
    /// daftar story di StoryBar; membuka story digate di sisi client (login).
    async fn list_groups_public(&self) -> Result<Vec<StoryGroupResponse>>;

    /// Arsip story publik per USER (halaman /stories): satu grup per user —
    /// termasuk story yang sudah expired — diurutkan berdasarkan story terbaru
    /// tiap user. Paginasi per user (limit/offset = jumlah user, bukan story).
    async fn list_user_groups_paged(
        &self,
        limit: i64,
        offset: i64,
    ) -> Result<Vec<StoryGroupResponse>>;

    /// Tandai story sudah dilihat oleh viewer.
    async fn mark_viewed(&self, story_id: &str, viewer_id: &str) -> Result<()>;

    /// Hapus story — hanya oleh owner. Mengembalikan `media_url` story yang
    /// terhapus (agar file di bucket bisa ikut dibersihkan), atau `None` bila
    /// tidak ada yang terhapus (story tak ada / bukan milik owner).
    async fn delete(&self, story_id: &str, owner_id: &str) -> Result<Option<String>>;

    /// Story milik satu user sebagai SATU grup (aktif + expired), terbaru dulu —
    /// dipakai viewer "Story Saya" di profil. Vec kosong bila belum ada story.
    async fn list_my_group(&self, user_id: &str) -> Result<Vec<StoryGroupResponse>>;

    /// Ambil satu story by id.
    async fn find_by_id(&self, story_id: &str) -> Result<Option<Story>>;

    /// Aktifkan premium subscription untuk user — buat subscription_order + user_subscription.
    async fn activate_premium(
        &self,
        user_id: &str,
        plan: &str,
        days: i64,
    ) -> Result<SubscriptionActivation>;

    /// Buat subscription_order dengan status 'pending' — belum aktifkan premium.
    async fn create_pending_subscription_order(
        &self,
        user_id: &str,
        plan: &str,
    ) -> Result<PendingSubOrder>;

    /// Konfirmasi pembayaran: tandai order sebagai 'paid' lalu aktifkan premium.
    async fn confirm_subscription_order(
        &self,
        order_id: &str,
        user_id: &str,
        plan: &str,
        days: i64,
    ) -> Result<SubscriptionActivation>;
}

// ── PostgreSQL implementation ─────────────────────────────────────────────────

pub struct PgStoryRepository {
    pool: Pool,
}

impl PgStoryRepository {
    pub fn new(pool: Pool) -> Self {
        Self { pool }
    }
}

#[async_trait]
impl StoryRepository for PgStoryRepository {
    // ── Premium check ─────────────────────────────────────────────────────────

    async fn is_premium(&self, user_id: &str) -> Result<bool> {
        let uid = id_to_vec(user_id)?;
        let conn = get_conn(&self.pool).await?;
        // prepare_cached: dipanggil di setiap create-order → jalur panas.
        let stmt = conn
            .prepare_cached(
                r#"
                SELECT 1 FROM user_subscriptions
                WHERE  user_id   = $1
                  AND  is_active = TRUE
                  AND  expires_at > NOW()
                LIMIT 1
                "#,
            )
            .await
            .context("is_premium prepare")?;
        let row = conn
            .query_opt(&stmt, &[&uid])
            .await
            .context("is_premium query")?;
        Ok(row.is_some())
    }

    // ── Daily story count ─────────────────────────────────────────────────────

    async fn count_today(&self, user_id: &str) -> Result<i64> {
        let uid = id_to_vec(user_id)?;
        let conn = get_conn(&self.pool).await?;
        let stmt = conn
            .prepare_cached(
                r#"
                SELECT COUNT(*)::BIGINT
                FROM   stories
                WHERE  user_id    = $1
                  AND  created_at >= DATE_TRUNC('day', NOW() AT TIME ZONE 'UTC')
                "#,
            )
            .await
            .context("count_today prepare")?;
        let row = conn
            .query_one(&stmt, &[&uid])
            .await
            .context("count_today query")?;
        Ok(row.try_get::<_, i64>(0)?)
    }

    // ── Create story ──────────────────────────────────────────────────────────

    async fn create(
        &self,
        user_id: &str,
        media_url: &str,
        media_type: &str,
        filter: Option<&str>,
        overlays: &[JsonValue],
        event_id: Option<&str>,
        event_slug: Option<&str>,
        event_title: Option<&str>,
    ) -> Result<Story> {
        let id_bytes = {
            let ulid = new_ulid();
            ulid_to_vec(&ulid)?
        };
        let uid = id_to_vec(user_id)?;
        let event_id_bytes: Option<Vec<u8>> = match event_id {
            Some(eid) => Some(id_to_vec(eid)?),
            None => None,
        };

        let overlays_json = serde_json::Value::Array(overlays.to_vec());

        let conn = get_conn(&self.pool).await?;
        let stmt = conn
            .prepare_cached(
                r#"
                INSERT INTO stories
                    (id, user_id, media_url, media_type, filter, overlays,
                     event_id, event_slug, event_title,
                     expires_at)
                VALUES
                    ($1, $2, $3, $4, $5, $6,
                     $7, $8, $9,
                     NOW() + INTERVAL '24 hours')
                RETURNING
                    id, user_id, media_url, media_type, filter, overlays,
                    event_id, event_slug, event_title, created_at, expires_at
                "#,
            )
            .await
            .context("insert story prepare")?;
        let row = conn
            .query_one(
                &stmt,
                &[
                    &id_bytes,
                    &uid,
                    &media_url,
                    &media_type,
                    &filter,
                    &overlays_json,
                    &event_id_bytes,
                    &event_slug,
                    &event_title,
                ],
            )
            .await
            .context("insert story")?;

        row_to_story(&row)
    }

    // ── List groups ───────────────────────────────────────────────────────────

    async fn list_groups(&self, viewer_id: &str) -> Result<Vec<StoryGroupResponse>> {
        let vid = id_to_vec(viewer_id)?;
        let conn = get_conn(&self.pool).await?;

        // Ambil semua story aktif beserta info view (prepare_cached: jalur
        // panas — StoryBar memanggil ini di tiap kunjungan Explore/Messages).
        let stmt = conn
            .prepare_cached(
                r#"
                SELECT
                    s.id,
                    s.user_id,
                    COALESCE(u.name, 'Unknown')       AS username,
                    COALESCE(u.avatar_url, '')         AS avatar_url,
                    s.media_url,
                    s.media_type,
                    s.filter,
                    s.overlays,
                    s.created_at,
                    s.expires_at,
                    s.event_id,
                    s.event_slug,
                    s.event_title,
                    (sv.viewer_id IS NOT NULL)         AS viewed
                FROM   stories s
                JOIN   users u   ON u.id = s.user_id
                LEFT   JOIN story_views sv
                       ON sv.story_id = s.id AND sv.viewer_id = $1
                WHERE  s.expires_at > NOW()
                ORDER BY
                    -- story milik viewer sendiri muncul pertama
                    (s.user_id = $1) DESC,
                    s.user_id,
                    s.created_at ASC
                "#,
            )
            .await
            .context("list_groups prepare")?;
        let rows = conn
            .query(&stmt, &[&vid])
            .await
            .context("list_groups query")?;

        rows_to_story_groups(&rows)
    }

    async fn list_groups_public(&self) -> Result<Vec<StoryGroupResponse>> {
        let conn = get_conn(&self.pool).await?;

        // Tanpa join story_views: viewer anonim tidak punya status `viewed`.
        let stmt = conn
            .prepare_cached(
                r#"
                SELECT
                    s.id,
                    s.user_id,
                    COALESCE(u.name, 'Unknown')       AS username,
                    COALESCE(u.avatar_url, '')         AS avatar_url,
                    s.media_url,
                    s.media_type,
                    s.filter,
                    s.overlays,
                    s.created_at,
                    s.expires_at,
                    s.event_id,
                    s.event_slug,
                    s.event_title,
                    FALSE                              AS viewed
                FROM   stories s
                JOIN   users u   ON u.id = s.user_id
                WHERE  s.expires_at > NOW()
                ORDER BY s.user_id, s.created_at ASC
                "#,
            )
            .await
            .context("list_groups_public prepare")?;
        let rows = conn
            .query(&stmt, &[])
            .await
            .context("list_groups_public query")?;

        rows_to_story_groups(&rows)
    }

    async fn list_user_groups_paged(
        &self,
        limit: i64,
        offset: i64,
    ) -> Result<Vec<StoryGroupResponse>> {
        let conn = get_conn(&self.pool).await?;

        // TANPA filter expires_at: arsip menampilkan story yang pernah ada.
        // CTE memilih HALAMAN user (diurutkan story terbarunya), baru join
        // mengambil seluruh story milik user-user tersebut — story dalam grup
        // urut ASC agar viewer memutar dari yang paling lama.
        let stmt = conn
            .prepare_cached(
                r#"
                WITH paged_users AS (
                    SELECT user_id, MAX(created_at) AS latest_at
                    FROM   stories
                    GROUP  BY user_id
                    ORDER  BY latest_at DESC
                    LIMIT $1 OFFSET $2
                )
                SELECT
                    s.id,
                    s.user_id,
                    COALESCE(u.name, 'Unknown')       AS username,
                    COALESCE(u.avatar_url, '')         AS avatar_url,
                    s.media_url,
                    s.media_type,
                    s.filter,
                    s.overlays,
                    s.created_at,
                    s.expires_at,
                    s.event_id,
                    s.event_slug,
                    s.event_title,
                    FALSE                              AS viewed
                FROM   paged_users pu
                JOIN   stories s ON s.user_id = pu.user_id
                JOIN   users u   ON u.id = s.user_id
                ORDER BY pu.latest_at DESC, s.user_id, s.created_at ASC
                "#,
            )
            .await
            .context("list_user_groups_paged prepare")?;
        let rows = conn
            .query(&stmt, &[&limit, &offset])
            .await
            .context("list_user_groups_paged query")?;

        rows_to_story_groups(&rows)
    }

    // ── Mark viewed ───────────────────────────────────────────────────────────

    async fn mark_viewed(&self, story_id: &str, viewer_id: &str) -> Result<()> {
        let sid = id_to_vec(story_id)?;
        let vid = id_to_vec(viewer_id)?;
        let conn = get_conn(&self.pool).await?;
        let stmt = conn
            .prepare_cached(
                r#"
                INSERT INTO story_views (story_id, viewer_id)
                VALUES ($1, $2)
                ON CONFLICT DO NOTHING
                "#,
            )
            .await
            .context("mark_viewed prepare")?;
        conn.execute(&stmt, &[&sid, &vid])
            .await
            .context("mark_viewed")?;
        Ok(())
    }

    // ── Delete ────────────────────────────────────────────────────────────────

    async fn delete(&self, story_id: &str, owner_id: &str) -> Result<Option<String>> {
        let sid = id_to_vec(story_id)?;
        let oid = id_to_vec(owner_id)?;
        let conn = get_conn(&self.pool).await?;
        let stmt = conn
            .prepare_cached(
                "DELETE FROM stories WHERE id = $1 AND user_id = $2 RETURNING media_url",
            )
            .await
            .context("delete story prepare")?;
        let row = conn
            .query_opt(&stmt, &[&sid, &oid])
            .await
            .context("delete story")?;
        match row {
            Some(r) => Ok(Some(r.try_get::<_, String>("media_url")?)),
            None => Ok(None),
        }
    }

    // ── List grup story milik sendiri (untuk viewer "Story Saya") ──────────────

    async fn list_my_group(&self, user_id: &str) -> Result<Vec<StoryGroupResponse>> {
        let uid = id_to_vec(user_id)?;
        let conn = get_conn(&self.pool).await?;
        // Kolom identik dengan list_groups agar bisa dipetakan row_to_story_item.
        // `viewed` selalu FALSE (status dilihat tidak relevan untuk story sendiri).
        let stmt = conn
            .prepare_cached(
                r#"
                SELECT
                    s.id,
                    s.user_id,
                    COALESCE(u.name, 'Unknown')   AS username,
                    COALESCE(u.avatar_url, '')     AS avatar_url,
                    s.media_url,
                    s.media_type,
                    s.filter,
                    s.overlays,
                    s.created_at,
                    s.expires_at,
                    s.event_id,
                    s.event_slug,
                    s.event_title,
                    FALSE                          AS viewed
                FROM   stories s
                JOIN   users u ON u.id = s.user_id
                WHERE  s.user_id = $1
                ORDER BY s.created_at DESC
                "#,
            )
            .await
            .context("list_my_group prepare")?;
        let rows = conn
            .query(&stmt, &[&uid])
            .await
            .context("list_my_group query")?;
        rows_to_story_groups(&rows)
    }

    // ── Find by id ────────────────────────────────────────────────────────────

    async fn find_by_id(&self, story_id: &str) -> Result<Option<Story>> {
        let sid = id_to_vec(story_id)?;
        let conn = get_conn(&self.pool).await?;
        let stmt = conn
            .prepare_cached(
                r#"
                SELECT id, user_id, media_url, media_type, filter, overlays,
                       event_id, event_slug, event_title, created_at, expires_at
                FROM   stories
                WHERE  id = $1
                "#,
            )
            .await
            .context("find_by_id story prepare")?;
        let row = conn
            .query_opt(&stmt, &[&sid])
            .await
            .context("find_by_id story")?;
        row.map(|r| row_to_story(&r)).transpose()
    }

    // ── Activate premium ──────────────────────────────────────────────────────

    async fn activate_premium(&self, user_id: &str, plan: &str, days: i64) -> Result<SubscriptionActivation> {
        let uid = id_to_vec(user_id)?;

        let order_ulid = new_ulid();
        let order_code = format!("SUB-{}", &order_ulid.to_uppercase()[..8]);
        let order_id_bytes = ulid_to_vec(&order_ulid)?;

        let amount: rust_decimal::Decimal = match plan {
            "weekly"   => rust_decimal_macros::dec!(9900.00),
            "yearly"   => rust_decimal_macros::dec!(199000.00),
            "lifetime" => rust_decimal_macros::dec!(499000.00),
            _          => rust_decimal_macros::dec!(29000.00),
        };

        let sub_id_bytes = ulid_to_vec(&new_ulid())?;

        let conn = get_conn(&self.pool).await?;

        // 1. Buat subscription_order (billing record)
        conn.execute(
            r#"
            INSERT INTO subscription_orders
                (id, user_id, order_code, plan, amount, status, paid_at)
            VALUES
                ($1, $2, $3, $4, $5, 'paid', NOW())
            "#,
            &[&order_id_bytes, &uid, &order_code, &plan, &amount],
        )
        .await
        .context("insert subscription_order")?;

        // 2. Nonaktifkan subscription lama
        conn.execute(
            "UPDATE user_subscriptions SET is_active = FALSE WHERE user_id = $1 AND is_active = TRUE",
            &[&uid],
        )
        .await
        .context("deactivate old subscription")?;

        // 3. Buat user_subscription baru, link ke subscription_order
        let row = if plan == "lifetime" {
            conn.query_one(
                r#"
                INSERT INTO user_subscriptions
                    (id, user_id, subscription_order_id, plan, expires_at)
                VALUES
                    ($1, $2, $3, $4, '9999-12-31 23:59:59+00'::timestamptz)
                RETURNING id, user_id, plan, started_at, expires_at, is_active, created_at
                "#,
                &[&sub_id_bytes, &uid, &order_id_bytes, &plan],
            )
            .await
            .context("activate premium lifetime")?
        } else {
            conn.query_one(
                r#"
                INSERT INTO user_subscriptions
                    (id, user_id, subscription_order_id, plan, expires_at)
                VALUES
                    ($1, $2, $3, $4, NOW() + ($5::BIGINT * INTERVAL '1 day'))
                RETURNING id, user_id, plan, started_at, expires_at, is_active, created_at
                "#,
                &[&sub_id_bytes, &uid, &order_id_bytes, &plan, &days],
            )
            .await
            .context("activate premium")?
        };

        let subscription = row_to_subscription(&row)?;
        Ok(SubscriptionActivation { subscription, order_code })
    }

    async fn create_pending_subscription_order(&self, user_id: &str, plan: &str) -> Result<PendingSubOrder> {
        let uid = id_to_vec(user_id)?;
        let order_ulid = new_ulid();
        let order_code = format!("SUB-{}", &order_ulid.to_uppercase()[..8]);
        let order_id_bytes = ulid_to_vec(&order_ulid)?;

        let amount: rust_decimal::Decimal = match plan {
            "weekly"   => rust_decimal_macros::dec!(9900.00),
            "yearly"   => rust_decimal_macros::dec!(199000.00),
            "lifetime" => rust_decimal_macros::dec!(499000.00),
            _          => rust_decimal_macros::dec!(29000.00),
        };
        let amount_idr: i64 = amount.try_into().unwrap_or(29000);

        let conn = get_conn(&self.pool).await?;
        conn.execute(
            r#"INSERT INTO subscription_orders
                   (id, user_id, order_code, plan, amount, status)
               VALUES ($1, $2, $3, $4, $5, 'pending')"#,
            &[&order_id_bytes, &uid, &order_code, &plan, &amount],
        )
        .await
        .context("create pending subscription order")?;

        Ok(PendingSubOrder { order_id: order_ulid, order_code, plan: plan.to_string(), amount_idr })
    }

    async fn confirm_subscription_order(
        &self,
        order_id: &str,
        user_id: &str,
        plan: &str,
        days: i64,
    ) -> Result<SubscriptionActivation> {
        let uid = id_to_vec(user_id)?;
        let order_id_bytes = ulid_to_vec(order_id)?;
        let sub_id_bytes = ulid_to_vec(&new_ulid())?;

        let conn = get_conn(&self.pool).await?;

        // Fetch order_code AND plan from the existing order.
        // SECURITY: the granted plan/duration MUST come from the stored order
        // (set at create_pending_subscription_order time alongside the charged
        // amount), NOT from the caller. Otherwise a user could create a cheap
        // `weekly` order then confirm with plan="lifetime" to escalate the
        // entitlement they actually paid for. The `plan`/`days` arguments are
        // therefore ignored here and re-derived from the persisted row.
        let order_row = conn
            .query_one(
                "SELECT order_code, plan FROM subscription_orders WHERE id = $1 AND user_id = $2 AND status = 'pending'",
                &[&order_id_bytes, &uid],
            )
            .await
            .context("find pending subscription order")?;
        let _ = (plan, days); // caller-supplied values ignored; superseded below
        let order_code: String = order_row.try_get(0)?;
        let plan: String = order_row.try_get(1)?;
        let days: i64 = match plan.as_str() {
            "weekly" => 7,
            "yearly" => 365,
            "lifetime" => 0,
            _ => 30, // monthly / default
        };

        // Mark as paid
        conn.execute(
            "UPDATE subscription_orders SET status = 'paid', paid_at = NOW() WHERE id = $1",
            &[&order_id_bytes],
        )
        .await
        .context("confirm subscription payment")?;

        // Deactivate old subscriptions
        conn.execute(
            "UPDATE user_subscriptions SET is_active = FALSE WHERE user_id = $1 AND is_active = TRUE",
            &[&uid],
        )
        .await
        .context("deactivate old subscription")?;

        // Create new subscription
        let row = if plan == "lifetime" {
            conn.query_one(
                r#"INSERT INTO user_subscriptions
                       (id, user_id, subscription_order_id, plan, expires_at)
                   VALUES ($1, $2, $3, $4, '9999-12-31 23:59:59+00'::timestamptz)
                   RETURNING id, user_id, plan, started_at, expires_at, is_active, created_at"#,
                &[&sub_id_bytes, &uid, &order_id_bytes, &plan],
            )
            .await
            .context("activate premium lifetime")?
        } else {
            conn.query_one(
                r#"INSERT INTO user_subscriptions
                       (id, user_id, subscription_order_id, plan, expires_at)
                   VALUES ($1, $2, $3, $4, NOW() + ($5::BIGINT * INTERVAL '1 day'))
                   RETURNING id, user_id, plan, started_at, expires_at, is_active, created_at"#,
                &[&sub_id_bytes, &uid, &order_id_bytes, &plan, &days],
            )
            .await
            .context("activate premium confirm")?
        };

        let subscription = row_to_subscription(&row)?;
        Ok(SubscriptionActivation { subscription, order_code })
    }
}
