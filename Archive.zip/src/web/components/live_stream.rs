use leptos::prelude::*;
use send_wrapper::SendWrapper;
use serde::Deserialize;
use wasm_bindgen::{JsCast, JsValue};
use wasm_bindgen::closure::Closure;
use std::rc::Rc;
use std::cell::Cell;

/// Semua wasm-bindgen `Closure` milik satu sesi tontonan. DIPEGANG (bukan
/// `.forget()`) supaya bisa di-DROP saat disconnect/unmount → tak bocor tiap
/// kali penonton membuka stream. Penting di feed `/lives` yang bisa membuka
/// banyak kartu berturut-turut. Cerminan pola publisher di `merchant_live.rs`.
struct ViewerRtcClosures {
    _on_track: Closure<dyn FnMut(web_sys::RtcTrackEvent)>,
    _on_msg: Closure<dyn FnMut(web_sys::MessageEvent)>,
    _on_err: Closure<dyn FnMut(web_sys::Event)>,
    _on_ice: Closure<dyn FnMut(web_sys::RtcPeerConnectionIceEvent)>,
}

// Hanya field yang dipakai UI viewer; field lain di respons diabaikan serde.
#[derive(Debug, Clone, Deserialize)]
struct RoomInfo {
    merchant_name: String,
    viewer_count: usize,
}

async fn api_get_room(room_id: &str) -> Result<RoomInfo, String> {
    let url = format!("/api/live/rooms/{}", room_id);
    let resp = gloo_net::http::Request::get(&url)
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let json: serde_json::Value = resp.json().await.map_err(|e| e.to_string())?;
    if let Some(err) = json.get("error").and_then(|e| e.as_str()) {
        return Err(err.to_string());
    }
    serde_json::from_value(json["data"].clone()).map_err(|e| e.to_string())
}

/// Bangun URL WebSocket dari path relatif.
/// Otomatis menggunakan wss:// bila halaman di-serve via HTTPS.
fn build_ws_url(path: &str) -> String {
    #[cfg(target_arch = "wasm32")]
    {
        let window = web_sys::window().expect("no window");
        let location = window.location();
        let proto = if location.protocol().unwrap_or_default() == "https:" {
            "wss"
        } else {
            "ws"
        };
        let host = location.host().unwrap_or_default();
        return format!("{}://{}{}", proto, host, path);
    }
    #[cfg(not(target_arch = "wasm32"))]
    format!("ws://localhost{}", path)
}

/// Bangun daftar ICE server sebagai array berisi objek JS biasa.
/// `serde_wasm_bindgen` (default) menserialisasi map jadi `Map` JS — bukan
/// object — sehingga `RTCIceServer.urls` tak terbaca dan konstruktor
/// RTCPeerConnection menolak ("urls is required"). Maka dibangun manual.
/// Helper: add a recvonly transceiver using raw JS
/// web-sys 0.3.99 does NOT have `add_transceiver_with_str_and_init`,
/// so we call the JS method directly via Reflect.
fn add_recvonly_transceiver(
    pc: &web_sys::RtcPeerConnection,
    kind: &str,
) -> Result<(), JsValue> {
    let init = js_sys::Object::new();
    js_sys::Reflect::set(&init, &"direction".into(), &"recvonly".into())?;
    let _ = js_sys::Reflect::get(pc.as_ref(), &"addTransceiver".into())?
        .dyn_into::<js_sys::Function>()?
        .call2(pc.as_ref(), &kind.into(), &init)?;
    Ok(())
}

#[component]
pub fn LiveStreamViewer(
    room_id: String,
    /// Bila true, langsung menyambung tanpa menunggu klik (dipakai di feed lives).
    #[prop(optional)]
    autoplay: bool,
) -> impl IntoView {
    // StoredValue (Copy) supaya bisa dipakai di beberapa closure `move`
    // (polling effect, connect, disconnect, on_cleanup) tanpa konflik move.
    let room_id = StoredValue::new(room_id);
    // Identitas penonton (jika login) dikirim ke server saat subscribe agar
    // merchant bisa melihat siapa saja yang join.
    let auth = crate::web::hooks::use_auth();
    let is_playing = RwSignal::new(false);
    // Viewer mulai muted (syarat autoplay browser). Tombol kustom mengubahnya.
    let is_muted = RwSignal::new(true);
    let viewer_count = RwSignal::new(0u32);
    let merchant_name = RwSignal::new(String::new());
    let error_msg = RwSignal::new(None::<String>);
    let pc: RwSignal<Option<SendWrapper<web_sys::RtcPeerConnection>>> = RwSignal::new(None);
    // Stream remote yang dirakit dari track yang masuk (audio + video).
    let remote_stream: RwSignal<Option<SendWrapper<web_sys::MediaStream>>> = RwSignal::new(None);
    let video_ref: NodeRef<leptos::html::Video> = NodeRef::new();
    // Koneksi WS signaling yang sedang aktif.
    // Menutup WS ini secara otomatis memanggil remove_subscriber di server —
    // tidak perlu lagi HTTP DELETE /subscribe/{id} saat keluar.
    let sig_ws: RwSignal<Option<SendWrapper<web_sys::WebSocket>>> = RwSignal::new(None);
    // Penampung closure RTC/WS sesi ini — dipegang agar bisa di-drop saat
    // disconnect/unmount (bukan `.forget()` yang bocor permanen). SendWrapper
    // memenuhi bound Send StoredValue (single-thread WASM; no-op native).
    let rtc_closures: StoredValue<Option<SendWrapper<ViewerRtcClosures>>> = StoredValue::new(None);

    // ── Polling viewer count ──────────────────────────────────────────────
    Effect::new(move |_| {
        if !is_playing.get() {
            return;
        }
        let rid = room_id.get_value();
        let vc = viewer_count;

        // SendWrapper: `Interval` memegang closure non-Send, sedangkan `on_cleanup`
        // menuntut Send+Sync agar tetap type-check di target native (efek hanya
        // benar-benar dijalankan di klien/WASM, jadi tak ada drop lintas-thread).
        let interval = SendWrapper::new(gloo_timers::callback::Interval::new(5_000, move || {
            let rid = rid.clone();
            let vc = vc;
            wasm_bindgen_futures::spawn_local(async move {
                if let Ok(room) = api_get_room(&rid).await {
                    vc.set(room.viewer_count as u32);
                }
            });
        }));

        on_cleanup(move || drop(interval));
    });

    let connect = Action::new_local(move |_: &()| {
        let room_id = room_id.get_value();
        let is_playing = is_playing;
        let viewer_count = viewer_count;
        let merchant_name = merchant_name;
        let error_msg = error_msg;
        let pc = pc;
        // video_ref tidak dipakai di sini: srcObject + play() dipasang oleh
        // Effect reaktif level-komponen saat `remote_stream` berubah.
        let sig_ws = sig_ws;
        let rtc_closures = rtc_closures;
        let profile = auth.user.get_untracked();

        async move {
            error_msg.set(None);

            let room = match api_get_room(&room_id).await {
                Ok(r) => r,
                Err(e) => {
                    error_msg.set(Some(format!("Stream not found: {e}")));
                    return;
                }
            };

            viewer_count.set(room.viewer_count as u32);
            merchant_name.set(room.merchant_name);

            let config = web_sys::RtcConfiguration::new();
            config.set_ice_servers(crate::web::rtc::fetch_ice_servers().await.as_ref());

            let peer_connection = web_sys::RtcPeerConnection::new_with_configuration(&config)
                .map_err(|e| format!("RTCPeerConnection failed: {:?}", e))
                .ok();

            let peer_connection = match peer_connection {
                Some(p) => p,
                None => {
                    error_msg.set(Some("WebRTC not supported".to_string()));
                    return;
                }
            };

            // ── Add recvonly transceivers BEFORE createOffer ──────────────────
            if let Err(e) = add_recvonly_transceiver(&peer_connection, "video") {
                error_msg.set(Some(format!("addTransceiver(video) failed: {:?}", e)));
                return;
            }
            if let Err(e) = add_recvonly_transceiver(&peer_connection, "audio") {
                error_msg.set(Some(format!("addTransceiver(audio) failed: {:?}", e)));
                return;
            }

            // ── ontrack: rakit track masuk → update signal saja ─────────────
            // Jangan manipulasi DOM dari sini (Closure JS, di luar sistem
            // reaktif Leptos) karena video_ref.get_untracked() bisa None.
            // Reactive Effect di bawah yang akan memasang srcObject + play().
            let on_track = {
                Closure::<dyn FnMut(web_sys::RtcTrackEvent)>::new(move |event: web_sys::RtcTrackEvent| {
                    // Selalu rakit SEMUA track masuk (audio + video) ke SATU
                    // MediaStream. JANGAN pakai event.streams()[0]: str0m memberi
                    // msid berbeda per track, jadi memakai streams[0] akan MENIMPA
                    // stream tiap kali ontrack terpicu → hanya track terakhir
                    // (audio) yang tersisa, track video hilang → video 0x0/hitam.
                    let stream = match remote_stream.get_untracked() {
                        Some(s) => (*s).clone(),
                        None => match web_sys::MediaStream::new() {
                            Ok(s) => s,
                            Err(_) => return,
                        },
                    };
                    // add_track idempoten (spec): aman walau ontrack terpicu ulang.
                    stream.add_track(&event.track());
                    // Signal update → reactive Effect merespons dan set srcObject.
                    remote_stream.set(Some(SendWrapper::new(stream)));
                })
            };
            peer_connection.set_ontrack(Some(on_track.as_ref().unchecked_ref()));
            // JANGAN forget: on_track dipegang & disimpan di rtc_closures (bawah).

            // ── Buka WS signaling SEBELUM createOffer ────────────────────────
            // Alasannya: setLocalDescription memulai ICE gathering. Kandidat ICE
            // pertama bisa datang sangat cepat. Dengan WS sudah terbuka, kandidat
            // langsung terkirim (trickle ICE sejati) — tidak perlu wait polling.
            let ws_url = build_ws_url(&format!("/ws/live/subscribe/{}", room_id));
            let ws = match web_sys::WebSocket::new(&ws_url) {
                Ok(w) => w,
                Err(e) => {
                    error_msg.set(Some(format!("WS gagal dibuka: {:?}", e)));
                    return;
                }
            };

            // Simpan WS segera agar on_cleanup bisa menutupnya walau
            // koneksi masih dalam proses (navigasi pergi sebelum selesai).
            sig_ws.set(Some(SendWrapper::new(ws.clone())));

            // ── Siapkan channel untuk menerima answer dari server ─────────────
            // Pola Rc<Cell<Option<Sender>>> aman di WASM (single-thread).
            // Cell::take() bekerja untuk Option<T> karena Option: Default.
            let (answer_tx, answer_rx) = futures::channel::oneshot::channel::<
                Result<serde_json::Value, String>,
            >();
            let answer_tx = Rc::new(Cell::new(Some(answer_tx)));

            let on_msg = {
                let tx = answer_tx.clone();
                let cb = Closure::<dyn FnMut(web_sys::MessageEvent)>::new(
                    move |e: web_sys::MessageEvent| {
                        if let Ok(txt) = e.data().dyn_into::<js_sys::JsString>() {
                            let s: String = txt.into();
                            if let Ok(v) = serde_json::from_str::<serde_json::Value>(&s) {
                                // Publisher mematikan siaran → server kirim
                                // "stream_ended". Keluarkan penonton: hentikan
                                // koneksi, bersihkan video, tampilkan info.
                                if v.get("type").and_then(|t| t.as_str()) == Some("stream_ended") {
                                    if let Some(conn) = pc.get_untracked() {
                                        let _ = conn.close();
                                    }
                                    pc.set(None);
                                    remote_stream.set(None);
                                    is_playing.set(false);
                                    is_muted.set(true);
                                    error_msg.set(Some("Siaran telah berakhir".to_string()));
                                    return;
                                }
                                if let Some(tx) = tx.take() {
                                    let _ = tx.send(Ok(v));
                                }
                            }
                        }
                    },
                );
                ws.set_onmessage(Some(cb.as_ref().unchecked_ref()));
                cb
            };
            let on_err = {
                let tx = answer_tx.clone();
                let cb = Closure::<dyn FnMut(web_sys::Event)>::new(move |_| {
                    if let Some(tx) = tx.take() {
                        let _ = tx.send(Err("WS error sebelum answer diterima".to_string()));
                    }
                });
                ws.set_onerror(Some(cb.as_ref().unchecked_ref()));
                cb
            };

            // ── onicecandidate: kirim kandidat langsung via WS (trickle ICE) ─
            // Tidak lagi menunggu ICE gathering selesai (wait_ice_gathering_complete
            // dihapus). Ini mempersingkat setup koneksi 300–500 ms.
            let on_ice = {
                let ws_ref = ws.clone();
                let cb = Closure::<dyn FnMut(web_sys::RtcPeerConnectionIceEvent)>::new(
                    move |event: web_sys::RtcPeerConnectionIceEvent| {
                        if let Some(candidate) = event.candidate() {
                            let msg = serde_json::json!({
                                "type": "candidate",
                                "candidate": candidate.candidate(),
                                "sdp_mid": candidate.sdp_mid().unwrap_or_default(),
                                "sdp_mline_index": candidate.sdp_m_line_index().unwrap_or(0),
                            });
                            let _ = ws_ref.send_with_str(&msg.to_string());
                        }
                    },
                );
                peer_connection.set_onicecandidate(Some(cb.as_ref().unchecked_ref()));
                cb
            };

            // ── Tunggu WS terbuka (maks 5 detik) ─────────────────────────────
            {
                use std::time::Duration;
                for _ in 0..50u8 {
                    match ws.ready_state() {
                        1 => break,                // OPEN
                        2 | 3 => {                 // CLOSING / CLOSED
                            error_msg.set(Some("WS ditutup sebelum terbuka".to_string()));
                            return;
                        }
                        _ => gloo_timers::future::sleep(Duration::from_millis(100)).await,
                    }
                }
                if ws.ready_state() != 1 {
                    error_msg.set(Some("WS koneksi timeout".to_string()));
                    return;
                }
            }

            // ── createOffer → setLocalDescription (ICE gathering dimulai) ────
            let offer_promise = peer_connection.create_offer_with_rtc_offer_options(
                &web_sys::RtcOfferOptions::new(),
            );
            let offer = match wasm_bindgen_futures::JsFuture::from(offer_promise).await {
                Ok(o) => o,
                Err(e) => {
                    error_msg.set(Some(format!("createOffer gagal: {:?}", e)));
                    return;
                }
            };

            let sdp_str = js_sys::Reflect::get(&offer, &wasm_bindgen::JsValue::from_str("sdp"))
                .unwrap()
                .as_string()
                .unwrap_or_default();

            let desc = web_sys::RtcSessionDescriptionInit::new(web_sys::RtcSdpType::Offer);
            desc.set_sdp(&sdp_str);

            if let Err(e) = wasm_bindgen_futures::JsFuture::from(
                peer_connection.set_local_description(&desc),
            )
            .await
            {
                error_msg.set(Some(format!("setLocalDescription gagal: {:?}", e)));
                return;
            }

            // Ambil SDP lokal saat ini (kandidat yang sudah terkumpul sebelum offer dikirim).
            let offer_sdp = peer_connection
                .local_description()
                .map(|d| d.sdp())
                .filter(|s| !s.is_empty())
                .unwrap_or(sdp_str);

            // ── Kirim offer via WS SINKRON (sebelum await berikutnya) ─────────
            // JavaScript single-thread: onicecandidate tidak bisa menyela sebelum kita await.
            // Dengan mengirim offer sinkron di sini, kita jamin server menerima offer
            // lebih dulu daripada kandidat ICE apapun.
            let (viewer_id, viewer_name) = match &profile {
                Some(p) => (Some(p.id.clone()), Some(p.name.clone())),
                None => (None, None),
            };
            let offer_msg = serde_json::json!({
                "type": "subscribe_offer",
                "sdp": offer_sdp,
                "viewer_id": viewer_id,
                "viewer_name": viewer_name,
            });
            if ws.send_with_str(&offer_msg.to_string()).is_err() {
                error_msg.set(Some("Gagal mengirim offer ke server".to_string()));
                return;
            }

            // ── Tunggu answer dari server (maks 15 detik) ────────────────────
            // answer_rx: Receiver<Result<Value, String>>
            // Awaiting: Result<Result<Value, String>, Canceled> — dua lapisan Result.
            let answer_json: serde_json::Value = match futures::future::select(
                Box::pin(answer_rx),
                Box::pin(gloo_timers::future::TimeoutFuture::new(15_000)),
            )
            .await
            {
                // Outer Ok = channel tidak dropped; inner Ok = server kirim answer JSON.
                futures::future::Either::Left((Ok(Ok(v)), _)) => v,
                // Outer Ok, inner Err = server kirim pesan error (misalnya "No active stream").
                futures::future::Either::Left((Ok(Err(e)), _)) => {
                    error_msg.set(Some(format!("Gagal terhubung: {e}")));
                    return;
                }
                // Outer Err = channel dropped (WS ditutup sebelum answer diterima).
                futures::future::Either::Left((Err(_), _)) => {
                    error_msg.set(Some("WS ditutup sebelum answer diterima".to_string()));
                    return;
                }
                futures::future::Either::Right(_) => {
                    error_msg.set(Some("Server tidak merespons (timeout 15 s)".to_string()));
                    return;
                }
            };

            // Periksa apakah server mengirim error
            if answer_json.get("type").and_then(|t| t.as_str()) == Some("error") {
                let msg = answer_json["message"].as_str().unwrap_or("Unknown error");
                error_msg.set(Some(format!("Gagal terhubung: {msg}")));
                return;
            }

            let answer_sdp = match answer_json["sdp"].as_str() {
                Some(s) => s.to_string(),
                None => {
                    error_msg.set(Some("Tidak ada SDP dalam answer".to_string()));
                    return;
                }
            };

            // ── setRemoteDescription dengan answer SDP ────────────────────────
            let answer_desc = web_sys::RtcSessionDescriptionInit::new(web_sys::RtcSdpType::Answer);
            answer_desc.set_sdp(&answer_sdp);

            if let Err(e) = wasm_bindgen_futures::JsFuture::from(
                peer_connection.set_remote_description(&answer_desc),
            )
            .await
            {
                error_msg.set(Some(format!("setRemoteDescription gagal: {:?}", e)));
                return;
            }

            // Pegang keempat closure selama sesi. Set_value me-REPLACE grup lama
            // (bila reconnect) → closure sesi sebelumnya otomatis di-drop.
            rtc_closures.set_value(Some(SendWrapper::new(ViewerRtcClosures {
                _on_track: on_track,
                _on_msg: on_msg,
                _on_err: on_err,
                _on_ice: on_ice,
            })));
            pc.set(Some(SendWrapper::new(peer_connection)));
            is_playing.set(true);
        }
    });

    // Auto-join sekali saat dipasang (feed lives): langsung connect tanpa tap.
    if autoplay {
        Effect::new(move |prev: Option<()>| {
            if prev.is_none() {
                connect.dispatch(());
            }
        });
    }

    let disconnect = Action::new_local(move |_: &()| {
        let pc = pc;
        let is_playing = is_playing;
        let sig_ws = sig_ws;
        let rtc_closures = rtc_closures;

        async move {
            if let Some(conn) = pc.get_untracked() {
                // Lepas handler SEBELUM drop closure (cegah "closure invoked
                // after drop"); close() juga menghentikan event lanjutan.
                conn.set_ontrack(None);
                conn.set_onicecandidate(None);
                let _ = conn.close();
            }
            pc.set(None);
            // Tutup WS → server memanggil remove_subscriber secara otomatis.
            // Tidak perlu lagi HTTP DELETE /subscribe/{id}.
            if let Some(ws) = sig_ws.get_untracked() {
                ws.set_onmessage(None);
                ws.set_onerror(None);
                let _ = ws.close();
            }
            sig_ws.set(None);
            // Drop keempat closure sesi ini → tak bocor.
            rtc_closures.set_value(None);
            is_playing.set(false);
            is_muted.set(true);
        }
    });

    on_cleanup(move || {
        if let Some(conn) = pc.get_untracked() {
            conn.set_ontrack(None);
            conn.set_onicecandidate(None);
            let _ = conn.close();
        }
        // Menutup WS secara otomatis memanggil remove_subscriber di server
        // (live_subscribe_ws_loop mendeteksi disconnect dan memanggil remove_subscriber).
        // Ini menangani: navigasi keluar, tutup tab, refresh saat masih menonton.
        if let Some(ws) = sig_ws.get_untracked() {
            ws.set_onmessage(None);
            ws.set_onerror(None);
            let _ = ws.close();
        }
        // Drop closure RTC/WS → tak bocor saat komponen unmount.
        rtc_closures.set_value(None);
    });

    // ── Reactive srcObject Effect ────────────────────────────────────────────
    // Diletakkan di level komponen (bukan di dalam Action) agar:
    //   1. video_ref.get() selalu bekerja — Effect berjalan di dalam sistem
    //      reaktif Leptos sehingga NodeRef terlacak dan selalu valid.
    //   2. play() dijadwalkan ulang tiap kali stream berubah (reconnect) tanpa
    //      perlu menyentuh DOM secara manual dari dalam wasm_bindgen Closure.
    //   3. Promise rejection dari play() ditangani via spawn_local (tidak
    //      dibuang diam-diam), sehingga konsol tidak penuh "Uncaught in promise".
    //
    // Alur: ontrack Closure → remote_stream.set() → Effect ini berjalan →
    //       set_src_object → play().
    Effect::new(move |_| {
        let Some(video) = video_ref.get() else { return };
        match remote_stream.get() {
            Some(stream) => {
                // set_src_object mungkin mengembalikan error jika element
                // sedang di-garbage-collect — abaikan saja.
                let _ = video.set_src_object(Some(&*stream));

                // Set property `muted` secara eksplisit (atribut `muted` tidak
                // selalu ter-refleksi ke property). Tanpa ini, autoplay media
                // ber-audio ditolak browser → video tetap hitam/pause.
                video.set_muted(true);

                // play() robust dengan retry. Safari sering MENOLAK play() saat
                // dipanggil tepat setelah set_src_object (metadata belum siap)
                // → video tetap pause/hitam walau frame sudah mengalir. Coba
                // berulang dengan jeda pendek sampai benar-benar berjalan; berhenti
                // begitu elemen tidak lagi `paused` (mis. user menekan kontrol).
                let video = video.clone();
                wasm_bindgen_futures::spawn_local(async move {
                    use std::time::Duration;
                    for _ in 0..25u8 {
                        if !video.paused() {
                            break;
                        }
                        // Pastikan tetap muted tiap percobaan (syarat autoplay).
                        video.set_muted(true);
                        if let Ok(promise) = video.play() {
                            if wasm_bindgen_futures::JsFuture::from(promise).await.is_ok() {
                                break;
                            }
                        }
                        gloo_timers::future::sleep(Duration::from_millis(200)).await;
                    }
                });
            }
            None => {
                // Stream dihentikan (disconnect) — bersihkan srcObject agar
                // elemen video tidak menahan referensi lama (memory leak).
                video.set_src_object(None);
            }
        }
    });

    view! {
        <div class="live-viewer">
            <div class="live-viewer-header">
                {move || {
                    if !merchant_name.get().is_empty() {
                        view! {
                            <span class="live-viewer-merchant">{move || merchant_name.get()}</span>
                        }
                            .into_any()
                    } else {
                        view! { <span></span> }.into_any()
                    }
                }}
                {move || {
                    if is_playing.get() {
                        view! {
                            <span class="live-viewer-badge">
                                <span class="live-viewer-dot"></span>
                                "LIVE"
                            </span>
                        }
                            .into_any()
                    } else {
                        view! { <span></span> }.into_any()
                    }
                }}
            </div>

            <div class="live-viewer-video-wrap">
                <video
                    node_ref=video_ref
                    class="live-viewer-video"
                    autoplay=true
                    // muted WAJIB: browser memblokir autoplay media ber-audio tanpa
                    // gesture. Mulai muted agar video langsung jalan; user unmute
                    // lewat tombol kustom di bawah (gesture → suara dijamin nyala).
                    muted=true
                    playsinline=true
                    poster="/live-poster.svg"
                />
                {move || {
                    if is_playing.get() {
                        // Saat masih muted, tampilkan tombol kustom "ketuk untuk
                        // suara". Klik = gesture user → set_muted(false) + play()
                        // dijamin diizinkan browser (termasuk Safari yang ketat).
                        if is_muted.get() {
                            view! {
                                // Seluruh area video bisa diketuk untuk menyalakan
                                // suara. Klik = gesture user → set_muted(false) +
                                // play() (dijamin diizinkan browser, termasuk Safari).
                                <button
                                    class="live-viewer-unmute-overlay"
                                    on:click=move |_| {
                                        if let Some(v) = video_ref.get_untracked() {
                                            v.set_muted(false);
                                            if let Ok(p) = v.play() {
                                                wasm_bindgen_futures::spawn_local(async move {
                                                    let _ = wasm_bindgen_futures::JsFuture::from(p).await;
                                                });
                                            }
                                        }
                                        is_muted.set(false);
                                    }
                                >
                                    <span class="live-viewer-unmute-pill">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                             stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                             stroke-linejoin="round">
                                            <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>
                                            <line x1="23" y1="9" x2="17" y2="15"/>
                                            <line x1="17" y1="9" x2="23" y2="15"/>
                                        </svg>
                                        "Ketuk untuk suara"
                                    </span>
                                </button>
                            }
                                .into_any()
                        } else {
                            view! { <span></span> }.into_any()
                        }
                    } else if connect.pending().get() {
                        view! {
                            <div class="live-viewer-overlay">
                                <span class="live-viewer-spinner"></span>
                                <p>"Menghubungkan..."</p>
                            </div>
                        }
                            .into_any()
                    } else {
                        // Seluruh overlay bisa diklik untuk bergabung.
                        view! {
                            <button
                                class="live-viewer-overlay live-viewer-overlay--btn"
                                on:click=move |_| { connect.dispatch(()); }
                            >
                                <span class="live-viewer-play">
                                    <svg width="22" height="22" viewBox="0 0 24 24"
                                         fill="currentColor">
                                        <polygon points="6 4 20 12 6 20 6 4" />
                                    </svg>
                                </span>
                                <p>"Ketuk untuk menonton siaran langsung"</p>
                            </button>
                        }
                            .into_any()
                    }
                }}
            </div>

            <div class="live-viewer-controls">
                <span class="live-viewer-viewers">
                    <svg
                        width="14"
                        height="14"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        stroke-width="2"
                        stroke-linecap="round"
                    >
                        <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" />
                        <circle cx="9" cy="7" r="4" />
                        <path d="M23 21v-2a4 4 0 00-3-3.87" />
                        <path d="M16 3.13a4 4 0 010 7.75" />
                    </svg>
                    {move || format!("{}", viewer_count.get())}
                </span>

                {move || {
                    if is_playing.get() {
                        view! {
                            <button
                                class="live-viewer-btn live-viewer-btn--leave"
                                on:click=move |_| {
                                    disconnect.dispatch(());
                                }
                            >
                                "Keluar"
                            </button>
                        }
                            .into_any()
                    } else {
                        view! {
                            <button
                                class="live-viewer-btn live-viewer-btn--join"
                                prop:disabled=move || connect.pending().get()
                                on:click=move |_| {
                                    connect.dispatch(());
                                }
                            >
                                <svg
                                    width="14"
                                    height="14"
                                    viewBox="0 0 24 24"
                                    fill="none"
                                    stroke="currentColor"
                                    stroke-width="2.5"
                                    stroke-linecap="round"
                                >
                                    <polygon points="5 3 19 12 5 21 5 3" />
                                </svg>
                                {move || if connect.pending().get() { "Menghubungkan" } else { "Tonton" }}
                            </button>
                        }
                            .into_any()
                    }
                }}
            </div>

            {move || error_msg.get().map(|e| view! { <div class="live-viewer-error">{e}</div> })}
        </div>
    }
}
