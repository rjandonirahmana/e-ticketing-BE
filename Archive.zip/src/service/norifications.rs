use reqwest::Client as HttpClient;
use serde_json::json;
use std::sync::Arc;
use tracing;

use crate::config::config::WahaConfig;
use crate::models::orders::OrderDetailResponse;
use crate::repository::user::UserRepository;
use crate::utils::phone::normalize_phone;

#[derive(Clone)]
pub struct NotificationService {
    http: HttpClient,
    waha: Arc<WahaConfig>,
    user_repo: Arc<dyn UserRepository>,
}

impl NotificationService {
    pub fn new(
        http: HttpClient,
        waha: Arc<WahaConfig>,
        user_repo: Arc<dyn UserRepository>,
    ) -> Self {
        Self {
            http,
            waha,
            user_repo,
        }
    }

    /// 🔥 Fire-and-forget: spawn task detached, tidak blocking response API.
    pub fn notify_order_created(&self, customer_id: String, order: OrderDetailResponse) {
        let svc = self.clone();
        tokio::spawn(async move {
            if let Err(e) = svc.send_order_wa(&customer_id, &order).await {
                tracing::error!(
                    customer_id,
                    order_id = %order.id,
                    error = %e,
                    "background WA order notification failed"
                );
            } else {
                tracing::info!(
                    customer_id,
                    order_id = %order.id,
                    "background WA order notification sent"
                );
            }
        });
    }

    async fn send_order_wa(
        &self,
        customer_id: &str,
        order: &OrderDetailResponse,
    ) -> anyhow::Result<()> {
        // 1. Lookup phone dari DB (background, tidak blocking API).
        let user = self
            .user_repo
            .find_by_id(customer_id)
            .await?
            .ok_or_else(|| anyhow::anyhow!("user {customer_id} not found"))?;

        let phone = normalize_phone(&user.phone)?;

        // 2. Build pesan.
        let mut text = format!(
            "🎫 *Pesanan Berhasil Dibuat!*\n\n\
             Kode Order: *{}*\n\
             Total: *{}*\n\n\
             *Detail Tiket:*\n",
            order.order_code, order.total_amount
        );

        for item in &order.items {
            text.push_str(&format!(
                "• {} ({})\n  {}x tiket\n\n",
                item.event_name, item.variant_name, item.quantity
            ));
        }

        text.push_str("Segera lakukan pembayaran sebelum order expired. Terima kasih! 🙏");

        // 3. Kirim via WAHA.
        let body = json!({
            "chatId": phone,
            "text": text,
            "session": self.waha.session,
        });

        let url = format!("{}/api/sendText", self.waha.base_url);
        let mut req = self.http.post(&url).json(&body);
        if !self.waha.api_key.is_empty() {
            req = req.header("X-Api-Key", &self.waha.api_key);
        }

        let res = req.send().await?;
        if !res.status().is_success() {
            let status = res.status();
            let body_text = res.text().await.unwrap_or_default();
            anyhow::bail!("WAHA error {status}: {body_text}");
        }

        Ok(())
    }
}
