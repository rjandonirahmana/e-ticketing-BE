use std::sync::Arc;

use axum::{
    extract::{
        ws::{Message, WebSocket, WebSocketUpgrade},
        Path, State,
    },
    http::StatusCode,
    response::{IntoResponse, Response},
    routing::{delete, get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};

use crate::middleware::auth::{require_auth, AuthUser};
use crate::state::AppState;
use tokio::sync::Semaphore;
use axum::middleware::from_fn_with_state;

/// Batas metadata penonton dari klien (anti-OOM — sama seperti meet):
/// tanpa cap, `viewer_photo` bisa berisi Base64 besar × 500 viewer × 200 room.
const MAX_VIEWER_NAME_LEN: usize = 100;
const MAX_VIEWER_PHOTO_LEN: usize = 512;

fn sanitize_viewer_name(raw: Option<&str>) -> Option<String> {
    raw.map(str::trim)
        .filter(|s| !s.is_empty())
        .map(|s| s.chars().take(MAX_VIEWER_NAME_LEN).collect())
}

fn sanitize_viewer_photo(raw: Option<&str>) -> Option<String> {
    raw.map(str::trim)
        .filter(|s| !s.is_empty() && !s.starts_with("data:"))
        .map(|s| s.chars().take(MAX_VIEWER_PHOTO_LEN).collect())
}

/// Otorisasi kontrol siaran: hanya PEMILIK room atau admin. Room id
/// deterministik (`live_{merchant_id}`) dan terpampang publik lewat
/// GET /api/live/rooms — tanpa cek ini, SEMUA user login bisa menghentikan
/// (stop_room) atau menyabot (publish ke) siaran merchant lain.
fn owns_room(auth: &AuthUser, room_id: &str) -> bool {
    auth.require_role("admin").is_ok() || room_id == format!("live_{}", auth.id())
}

fn ok<T: Serialize>(data: T) -> Response {
    (StatusCode::OK, Json(serde_json::json!({ "data": data }))).into_response()
}

fn err(status: StatusCode, msg: &str) -> Response {
    (status, Json(serde_json::json!({ "error": msg }))).into_response()
}

#[derive(Debug, Deserialize)]
pub struct CreateRoomReq {
    pub event_slug: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct SdpReq {
    pub sdp: String,
}

#[derive(Debug, Deserialize)]
pub struct SubscribeReq {
    pub sdp: String,
    #[serde(default)]
    pub viewer_id: Option<String>,
    #[serde(default)]
    pub viewer_name: Option<String>,
    #[serde(default)]
    pub viewer_photo: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct IceReq {
    pub candidate: String,
    pub sdp_mid: String,
    pub sdp_mline_index: u32,
}

#[derive(Debug, Deserialize)]
pub struct SubscribeIceReq {
    pub subscriber_id: String,
    pub candidate: String,
    pub sdp_mid: String,
    pub sdp_mline_index: u32,
}

#[derive(Debug, Serialize)]
pub struct SdpRes {
    pub sdp: String,
}

#[derive(Debug, Serialize)]
pub struct SubscribeSdpRes {
    pub sdp: String,
    pub subscriber_id: String,
}

async fn create_room(
    auth: AuthUser,
    State(state): State<Arc<AppState>>,
    Json(body): Json<CreateRoomReq>,
) -> Response {
    if auth.require_role("merchant").is_err() && auth.require_role("admin").is_err() {
        return err(StatusCode::FORBIDDEN, "Only merchants can go live");
    }

    match state
        .live_svc
        .create_room(auth.id(), auth.name(), body.event_slug.as_deref())
        .await
    {
        Ok(info) => ok(info),
        Err(e) => err(StatusCode::CONFLICT, &e),
    }
}

async fn list_rooms(State(state): State<Arc<AppState>>) -> Response {
    ok(state.live_svc.list_rooms())
}

/// Metrik runtime realtime untuk monitoring VPS kecil: jumlah WS aktif, room
/// chat, room+penonton live, room+peserta meet. Ringan (baca counter in-memory).
async fn stats(State(state): State<Arc<AppState>>) -> Response {
    let live = state.live_svc.list_rooms();
    let live_viewers: usize = live.iter().map(|r| r.viewer_count).sum();
    let meet = state.meet_svc.list_rooms();
    let meet_participants: usize = meet.iter().map(|r| r.participant_count).sum();
    let cap = &state.capacity;
    let ws_active = state.ws_mgr.online_count();
    let ws_max = state.ws_mgr.max_connections();
    ok(serde_json::json!({
        // Sumber daya VPS terdeteksi (cgroup-aware) + plafon turunannya.
        "cpu_cores": cap.cpu_cores,
        "ram_mb": cap.ram_bytes / (1024 * 1024),
        "source": cap.source,
        "ws_max": ws_max,
        "ws_capacity_pct": if ws_max > 0 { ws_active * 100 / ws_max } else { 0 },
        // Beban realtime saat ini.
        "ws_active": ws_active,
        "ws_dropped": state.ws_mgr.dropped(),
        "ws_rooms": state.ws_mgr.room_count(),
        "live_rooms": live.len(),
        "live_viewers": live_viewers,
        "meet_rooms": meet.len(),
        "meet_participants": meet_participants,
    }))
}

/// Daftar ICE server untuk semua klien WebRTC (live + meet). STUN publik selalu
/// disertakan; TURN ditambahkan bila `TURN_URL` di-set di env (lihat
/// `.env.example`). Browser tak bisa baca env server → diambil dari sini.
async fn ice_servers() -> Response {
    let mut servers = vec![serde_json::json!({
        "urls": ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"]
    })];
    if let Ok(url) = std::env::var("TURN_URL") {
        let url = url.trim();
        if !url.is_empty() {
            let mut turn = serde_json::json!({ "urls": [url] });
            if let Ok(u) = std::env::var("TURN_USER") {
                if !u.trim().is_empty() {
                    turn["username"] = serde_json::json!(u);
                }
            }
            if let Ok(p) = std::env::var("TURN_PASS") {
                if !p.trim().is_empty() {
                    turn["credential"] = serde_json::json!(p);
                }
            }
            servers.push(turn);
        }
    }
    ok(servers)
}

/// Selang ping untuk seluruh WS siaran langsung.
///
/// Tiga loop WS di berkas ini — `/ws/lives`, publisher, dan subscriber — bisa
/// DIAM berjam-jam: `/ws/lives` hanya bicara saat daftar room berubah, dan dua
/// lainnya hanya saat ICE bernegosiasi. Koneksi yang diam adalah koneksi yang
/// dibunuh perantara: Pingora di depan, lalu NAT operator seluler, memutus TCP
/// yang tak berlalu-lintas — dan putusnya muncul di log proxy sebagai
/// `Downstream ReadError ... Connection reset by peer` pada `/ws/lives`, bukan
/// sebagai galat apa pun di sisi aplikasi.
///
/// Angkanya ditentukan perantara yang paling ketat, dan itu Pingora di depan:
/// `pingora-core` memberi sesi downstream `read_timeout` bawaan **60 detik**
/// dan kinetic-proxy tak menimpanya, jadi socket yang tak mengirim satu frame
/// pun selama 60 detik diputus proxy — bukan oleh jaringan, bukan oleh browser.
///
/// 25 detik memberi dua kesempatan di dalam jendela itu; kalau satu tick telat
/// (runtime tersendat, dan itu pernah terjadi 3 Sep 2026), yang tersisa cuma
/// satu, dan socket-nya mati. 20 detik memberi tiga. Selisih bebannya nol yang
/// berarti — satu frame ping kosong per socket — sementara bedanya adalah
/// apakah sendatan sesaat berakhir sebagai badai reconnect atau tidak.
const WS_PING_INTERVAL: std::time::Duration = std::time::Duration::from_secs(20);

/// Pencacah ping yang tick pertamanya (yang instan) sudah dibuang.
fn ping_interval() -> tokio::time::Interval {
    let mut it = tokio::time::interval(WS_PING_INTERVAL);
    // `Skip`: kalau loop sempat sibuk melewati beberapa tick, jangan lalu
    // menembakkan ping bertubi-tubi untuk "mengejar" — yang dibutuhkan cuma
    // satu paket sesekali agar jalur tetap dianggap hidup.
    it.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    it
}

/// WS /ws/lives — push daftar room live realtime (pengganti polling).
/// Kirim snapshot saat connect, lalu tiap ada perubahan.
/// Plafon penonton yang mendengarkan daftar siaran sekaligus.
///
/// ── KENAPA HARUS ADA PLAFON ───────────────────────────────────────────────
/// Titik ini TERBUKA — tak menuntut masuk sama sekali, karena daftar siaran
/// memang publik. Tiap sambungan menahan satu tugas dan satu penerima siaran,
/// dan tanpa batas siapa pun bisa membuka ribuan sekaligus dari satu mesin.
///
/// Dulu itu nyaris tak berarti karena hanya halaman `/lives` yang memakainya.
/// Sejak penonton berhenti menjajak dan ikut mendengarkan di sini, titik ini
/// jadi jauh lebih ramai — dan yang ramai tanpa batas pada mesin 8 GB pada
/// akhirnya menjadi cara termudah menjatuhkannya.
///
/// Ditolak berarti angka penonton tak diperbarui; siarannya sendiri tetap
/// jalan. Itu kehilangan yang benar untuk dipilih di bawah tekanan.
static PENDENGAR_LIVES: std::sync::LazyLock<Arc<Semaphore>> =
    std::sync::LazyLock::new(|| Arc::new(Semaphore::new(3_000)));

async fn lives_ws(ws: WebSocketUpgrade, State(state): State<Arc<AppState>>) -> Response {
    let Ok(izin) = PENDENGAR_LIVES.clone().try_acquire_owned() else {
        tracing::warn!("WS /ws/lives ditolak: plafon pendengar tercapai");
        return (axum::http::StatusCode::SERVICE_UNAVAILABLE, "Terlalu banyak pendengar").into_response();
    };
    crate::ws::siapkan_sinyal(ws).on_upgrade(move |socket| async move {
        // Izin dipegang selama sambungan hidup, dilepas saat ia berakhir.
        let _izin = izin;
        lives_ws_loop(socket, state).await;
    })
}

async fn lives_ws_loop(mut socket: WebSocket, state: Arc<AppState>) {
    let mut rx = state.live_svc.subscribe_changes();

    let initial = serde_json::to_string(&state.live_svc.list_rooms()).unwrap_or_default();
    if socket.send(Message::Text(initial.into())).await.is_err() {
        return;
    }

    let mut ping = ping_interval();
    ping.tick().await; // tick pertama instan — buang

    loop {
        tokio::select! {
            _ = ping.tick() => {
                if socket.send(Message::Ping(bytes::Bytes::new())).await.is_err() {
                    break;
                }
            }
            update = rx.recv() => match update {
                Ok(list) => {
                    let txt = serde_json::to_string(&list).unwrap_or_default();
                    if socket.send(Message::Text(txt.into())).await.is_err() {
                        break;
                    }
                }
                Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                Err(_) => break,
            },
            msg = socket.recv() => match msg {
                Some(Ok(_)) => {}
                _ => break,
            },
        }
    }
}

async fn get_room(Path(room_id): Path<String>, State(state): State<Arc<AppState>>) -> Response {
    match state.live_svc.get_room(&room_id) {
        Some(info) => ok(info),
        None => err(StatusCode::NOT_FOUND, "Room not found"),
    }
}

// ── HTTP signaling (tetap ada untuk kompatibilitas klien lama) ─────────────────

async fn publish_sdp(
    auth: AuthUser,
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(body): Json<SdpReq>,
) -> impl IntoResponse {
    if !owns_room(&auth, &room_id) {
        return err(StatusCode::FORBIDDEN, "Bukan pemilik siaran ini");
    }
    match state.live_svc.publish_sdp(&room_id, &body.sdp).await {
        Ok(answer) => ok(SdpRes { sdp: answer }),
        Err(e) => err(StatusCode::BAD_REQUEST, &e),
    }
}

async fn publish_ice(
    auth: AuthUser,
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(body): Json<IceReq>,
) -> impl IntoResponse {
    if !owns_room(&auth, &room_id) {
        return err(StatusCode::FORBIDDEN, "Bukan pemilik siaran ini");
    }
    match state
        .live_svc
        .publish_ice(
            &room_id,
            &body.candidate,
            &body.sdp_mid,
            body.sdp_mline_index,
        )
        .await
    {
        Ok(()) => ok(serde_json::json!({ "ok": true })),
        Err(e) => err(StatusCode::BAD_REQUEST, &e),
    }
}

async fn subscribe_sdp(
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(body): Json<SubscribeReq>,
) -> impl IntoResponse {
    let sub_id = uuid::Uuid::new_v4().to_string();
    let viewer = crate::live::room::ViewerInfo {
        id: body.viewer_id.unwrap_or_else(|| sub_id.clone()),
        name: sanitize_viewer_name(body.viewer_name.as_deref())
            .unwrap_or_else(|| "Anonim".to_string()),
        photo_url: sanitize_viewer_photo(body.viewer_photo.as_deref()),
    };
    match state
        .live_svc
        .subscribe_sdp(&room_id, &sub_id, &body.sdp, viewer)
        .await
    {
        Ok(answer) => ok(SubscribeSdpRes {
            sdp: answer,
            subscriber_id: sub_id,
        }),
        Err(e) => err(StatusCode::BAD_REQUEST, &e),
    }
}

async fn subscribe_ice(
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(body): Json<SubscribeIceReq>,
) -> impl IntoResponse {
    match state
        .live_svc
        .subscribe_ice(
            &room_id,
            &body.subscriber_id,
            &body.candidate,
            &body.sdp_mid,
            body.sdp_mline_index,
        )
        .await
    {
        Ok(()) => ok(serde_json::json!({ "ok": true })),
        Err(e) => err(StatusCode::BAD_REQUEST, &e),
    }
}

async fn leave_room(
    Path((room_id, subscriber_id)): Path<(String, String)>,
    State(state): State<Arc<AppState>>,
) -> impl IntoResponse {
    match state
        .live_svc
        .remove_subscriber(&room_id, &subscriber_id)
        .await
    {
        Ok(()) => ok(serde_json::json!({ "ok": true })),
        Err(e) => err(StatusCode::BAD_REQUEST, &e),
    }
}

/// Batas jumlah produk yang boleh dipajang dalam satu siaran.
///
/// Bukan aturan bisnis melainkan plafon muatan: daftar ini ikut di SETIAP
/// snapshot yang disiarkan ke seluruh penonton lewat `/ws/lives`, jadi
/// panjangnya dikalikan jumlah penonton pada tiap perubahan. Tiga puluh sudah
/// jauh lebih banyak daripada yang bisa dibahas dalam satu siaran.
const MAX_PRODUK_LIVE: usize = 30;

#[derive(Debug, Deserialize)]
struct SetProductsReq {
    product_ids: Vec<String>,
}

/// PUT /api/live/rooms/{room_id}/products — merchant memilih produk yang dijual.
async fn set_room_products(
    auth: AuthUser,
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
    Json(body): Json<SetProductsReq>,
) -> impl IntoResponse {
    if !owns_room(&auth, &room_id) {
        return err(StatusCode::FORBIDDEN, "Bukan pemilik siaran ini");
    }
    if body.product_ids.len() > MAX_PRODUK_LIVE {
        return err(
            StatusCode::UNPROCESSABLE_ENTITY,
            "Terlalu banyak produk dipilih untuk satu siaran",
        );
    }
    // Duplikat DIBUANG di sini, bukan dibiarkan sampai ke layar penonton:
    // `set_products` memetakan id → urutan, jadi id kembar hanya akan saling
    // menimpa dan menghasilkan daftar yang lebih pendek dari yang dikirim —
    // perbedaan yang membingungkan justru bagi merchant yang mengirimnya.
    let mut ids = Vec::with_capacity(body.product_ids.len());
    for id in body.product_ids {
        if !ids.contains(&id) {
            ids.push(id);
        }
    }
    match state.live_svc.set_room_products(&room_id, &ids) {
        Ok(()) => ok(serde_json::json!({ "ok": true, "count": ids.len() })),
        Err(e) => err(StatusCode::NOT_FOUND, &e),
    }
}

async fn stop_room(
    auth: AuthUser,
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
) -> impl IntoResponse {
    if !owns_room(&auth, &room_id) {
        return err(StatusCode::FORBIDDEN, "Bukan pemilik siaran ini");
    }
    match state.live_svc.stop_room(&room_id).await {
        Ok(()) => ok(serde_json::json!({ "ok": true })),
        Err(e) => err(StatusCode::NOT_FOUND, &e),
    }
}

// ── WS signaling: publisher ────────────────────────────────────────────────────
//
// GET /ws/live/publish/{room_id}
//
// Protokol (JSON):
//   Client → Server: { "type": "publish_offer", "sdp": "..." }
//   Server → Client: { "type": "answer",        "sdp": "..." }
//   Server → Client: { "type": "error",         "message": "..." }
//   Client → Server: { "type": "candidate",
//                      "candidate": "...", "sdp_mid": "...", "sdp_mline_index": 0 }
//
// Keunggulan vs HTTP: trickle ICE sejati (kandidat dikirim satu per satu, real-time),
// tidak ada `wait_ice_gathering_complete` polling, setup koneksi 300-500 ms lebih cepat.
// Server otomatis memanggil stop_room saat WS ditutup (kamera mati / tab ditutup).

async fn live_publish_ws(
    auth: AuthUser,
    ws: WebSocketUpgrade,
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Response {
    // Cek kepemilikan SEBELUM upgrade: loop publisher memanggil stop_room saat
    // WS tutup — tanpa cek ini, siapa pun yang login bisa buka-tutup WS ke room
    // merchant lain dan mematikan siarannya.
    if !owns_room(&auth, &room_id) {
        return err(StatusCode::FORBIDDEN, "Bukan pemilik siaran ini");
    }
    crate::ws::siapkan_sinyal(ws).on_upgrade(move |socket| live_publish_ws_loop(socket, room_id, state))
}

async fn live_publish_ws_loop(mut socket: WebSocket, room_id: String, state: Arc<AppState>) {
    let mut negotiated = false;

    // Deadline negosiasi: WS publisher yang tak pernah mengirim offer tidak
    // boleh menahan socket selamanya. Timeout → break → stop_room membersihkan
    // room yatim miliknya (perilaku yang memang diinginkan, lihat komentar bawah).
    let offer_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);

    let mut ping = ping_interval();
    ping.tick().await; // tick pertama instan — buang

    loop {
        let frame = tokio::select! {
            f = socket.recv() => f,
            _ = tokio::time::sleep_until(offer_deadline), if !negotiated => {
                tracing::debug!(room_id, "live publish: offer timeout — koneksi ditutup");
                break;
            }
            // Ping tak menghasilkan frame untuk diproses di bawah; `continue`
            // supaya `match frame` tak perlu mengenal kasus "tak ada apa-apa".
            _ = ping.tick() => {
                if socket.send(Message::Ping(bytes::Bytes::new())).await.is_err() {
                    break;
                }
                continue;
            }
        };
        match frame {
            None | Some(Err(_)) => break,
            Some(Ok(Message::Close(_))) => break,
            Some(Ok(Message::Text(txt))) => {
                let v: serde_json::Value = match serde_json::from_str(&txt) {
                    Ok(v) => v,
                    Err(_) => continue,
                };
                match v.get("type").and_then(|t| t.as_str()).unwrap_or("") {
                    "publish_offer" => {
                        let sdp = v["sdp"].as_str().unwrap_or_default();
                        let resp = match state.live_svc.publish_sdp(&room_id, sdp).await {
                            Ok(answer) => {
                                negotiated = true;
                                serde_json::json!({ "type": "answer", "sdp": answer })
                            }
                            Err(e) => serde_json::json!({ "type": "error", "message": e }),
                        };
                        if socket
                            .send(Message::Text(resp.to_string().into()))
                            .await
                            .is_err()
                        {
                            break;
                        }
                    }
                    "candidate" if negotiated => {
                        let candidate = v["candidate"].as_str().unwrap_or_default();
                        let mid = v["sdp_mid"].as_str().unwrap_or_default();
                        let idx = v["sdp_mline_index"].as_u64().unwrap_or(0) as u32;
                        // Error silently ignored — ICE kadang kirim kandidat duplikat.
                        let _ = state
                            .live_svc
                            .publish_ice(&room_id, candidate, mid, idx)
                            .await;
                    }
                    _ => {}
                }
            }
            Some(Ok(_)) => {} // Binary/ping/pong — abaikan
        }
    }

    // Publisher terputus (tutup tab / klik STOP LIVE / navigasi pergi):
    // hentikan room agar tidak "menggantung". Dilakukan TANPA syarat `negotiated`
    // — bila WS publisher ditutup sebelum sempat mengirim offer (mis. room dibuat
    // via HTTP POST lalu WS gagal/ditutup), room tetap harus dibuang agar tidak
    // menjadi room yatim yang menumpuk di memori.
    tracing::info!(room_id, negotiated, "Publisher WS closed — stopping room");
    let _ = state.live_svc.stop_room(&room_id).await;
}

// ── WS signaling: subscriber (viewer) ─────────────────────────────────────────
//
// GET /ws/live/subscribe/{room_id}
//
// Protokol (JSON):
//   Client → Server: { "type": "subscribe_offer", "sdp": "...",
//                      "viewer_id": "...", "viewer_name": "..." }
//   Server → Client: { "type": "answer", "sdp": "...", "subscriber_id": "..." }
//   Server → Client: { "type": "error",  "message": "..." }
//   Client → Server: { "type": "candidate",
//                      "candidate": "...", "sdp_mid": "...", "sdp_mline_index": 0 }
//   Client → Server: { "type": "leave" }   (opsional, boleh langsung tutup WS)
//
// WS disconnect (apapun sebabnya) secara otomatis memanggil remove_subscriber
// sehingga jumlah penonton selalu akurat, tanpa perlu HTTP DELETE.

async fn live_subscribe_ws(
    ws: WebSocketUpgrade,
    Path(room_id): Path<String>,
    State(state): State<Arc<AppState>>,
) -> Response {
    crate::ws::siapkan_sinyal(ws).on_upgrade(move |socket| live_subscribe_ws_loop(socket, room_id, state))
}

async fn live_subscribe_ws_loop(mut socket: WebSocket, room_id: String, state: Arc<AppState>) {
    let sub_id = uuid::Uuid::new_v4().to_string();
    let mut subscribed = false;

    // Deadline negosiasi: koneksi yang tak pernah mengirim subscribe_offer
    // (half-open / port-scan / tab macet) tidak boleh menahan socket +
    // broadcast receiver selamanya. Arm select-nya nonaktif setelah subscribed.
    let join_deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(30);

    // Dengarkan perubahan daftar room. Saat publisher mematikan siaran, room
    // dihapus dari snapshot → kita beri tahu penonton ("stream_ended") lalu tutup
    // koneksi, sehingga seluruh penonton otomatis keluar dari live.
    let mut changes = state.live_svc.subscribe_changes();

    let mut ping = ping_interval();
    ping.tick().await; // tick pertama instan — buang

    loop {
        tokio::select! {
            _ = ping.tick() => {
                if socket.send(Message::Ping(bytes::Bytes::new())).await.is_err() {
                    break;
                }
            }
            // ── Belum subscribe melewati deadline → tutup (hemat resource) ────
            _ = tokio::time::sleep_until(join_deadline), if !subscribed => {
                tracing::debug!(room_id, "live subscribe: offer timeout — koneksi ditutup");
                break;
            }
            // ── Perubahan room: deteksi siaran berakhir ───────────────────────
            changed = changes.recv() => {
                match changed {
                    Ok(list) => {
                        if subscribed && !list.iter().any(|r| r.room_id == room_id) {
                            tracing::info!(room_id, sub_id, "Siaran berakhir → keluarkan penonton");
                            let _ = socket
                                .send(Message::Text(
                                    serde_json::json!({ "type": "stream_ended" }).to_string().into(),
                                ))
                                .await;
                            break;
                        }
                    }
                    // Ketinggalan beberapa update tak masalah: cek room di update berikutnya.
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => {}
                    Err(_) => break,
                }
            }

            // ── Pesan dari klien (offer / candidate / leave) ──────────────────
            msg = socket.recv() => {
        match msg {
            None | Some(Err(_)) => break,
            Some(Ok(Message::Close(_))) => break,
            Some(Ok(Message::Text(txt))) => {
                let v: serde_json::Value = match serde_json::from_str(&txt) {
                    Ok(v) => v,
                    Err(_) => continue,
                };
                match v.get("type").and_then(|t| t.as_str()).unwrap_or("") {
                    "subscribe_offer" => {
                        let sdp = v["sdp"].as_str().unwrap_or_default();
                        let viewer = crate::live::room::ViewerInfo {
                            id: v["viewer_id"]
                                .as_str()
                                .filter(|s| !s.is_empty())
                                .unwrap_or(&sub_id)
                                .to_string(),
                            name: sanitize_viewer_name(v["viewer_name"].as_str())
                                .unwrap_or_else(|| "Anonim".to_string()),
                            photo_url: sanitize_viewer_photo(v["viewer_photo"].as_str()),
                        };
                        let resp =
                            match state.live_svc.subscribe_sdp(&room_id, &sub_id, sdp, viewer).await {
                                Ok(answer) => {
                                    subscribed = true;
                                    serde_json::json!({
                                        "type": "answer",
                                        "sdp": answer,
                                        "subscriber_id": sub_id,
                                    })
                                }
                                Err(e) => serde_json::json!({ "type": "error", "message": e }),
                            };
                        if socket
                            .send(Message::Text(resp.to_string().into()))
                            .await
                            .is_err()
                        {
                            break;
                        }
                    }
                    "candidate" if subscribed => {
                        let candidate = v["candidate"].as_str().unwrap_or_default();
                        let mid = v["sdp_mid"].as_str().unwrap_or_default();
                        let idx = v["sdp_mline_index"].as_u64().unwrap_or(0) as u32;
                        let _ = state
                            .live_svc
                            .subscribe_ice(&room_id, &sub_id, candidate, mid, idx)
                            .await;
                    }
                    "leave" => break,
                    _ => {}
                }
            }
            Some(Ok(_)) => {}
        }
            }
        }
    }

    // Penonton putus (tutup tab, klik Keluar, navigasi pergi):
    // lepas dari room agar hitungan penonton akurat.
    if subscribed {
        let _ = state.live_svc.remove_subscriber(&room_id, &sub_id).await;
    }
}

// ── Router ─────────────────────────────────────────────────────────────────────

pub fn live_router(state: Arc<AppState>) -> Router {
    // Route yang memerlukan autentikasi merchant/admin.
    let protected = Router::new()
        .route("/api/live/rooms", post(create_room))
        // HTTP signaling (dipertahankan untuk kompatibilitas)
        .route("/api/live/rooms/{room_id}/publish/sdp", post(publish_sdp))
        .route("/api/live/rooms/{room_id}/publish/ice", post(publish_ice))
        .route("/api/live/rooms/{room_id}", delete(stop_room))
        // Merchant memilih produk yang dijual selama siaran. Ikut di router
        // ber-`require_auth` di bawah — daftar jualan bukan sesuatu yang boleh
        // diubah tanpa identitas.
        .route(
            "/api/live/rooms/{room_id}/products",
            axum::routing::put(set_room_products),
        )
        // WS signaling untuk publisher (auth via cookie — browser kirim otomatis)
        .route("/ws/live/publish/{room_id}", get(live_publish_ws))
        .layer(from_fn_with_state(state.clone(), require_auth));

    // Route publik (tidak perlu login).
    let public = Router::new()
        .route("/api/live/rooms", get(list_rooms))
        .route("/api/stats", get(stats))
        .route("/api/rtc/ice", get(ice_servers))
        .route("/ws/lives", get(lives_ws))
        .route("/api/live/rooms/{room_id}", get(get_room))
        // HTTP signaling (dipertahankan)
        .route(
            "/api/live/rooms/{room_id}/subscribe/sdp",
            post(subscribe_sdp),
        )
        .route(
            "/api/live/rooms/{room_id}/subscribe/ice",
            post(subscribe_ice),
        )
        .route(
            "/api/live/rooms/{room_id}/subscribe/{subscriber_id}",
            delete(leave_room),
        )
        // WS signaling untuk penonton (publik — tidak perlu login)
        .route("/ws/live/subscribe/{room_id}", get(live_subscribe_ws));

    Router::new()
        .merge(protected)
        .merge(public)
        .with_state(state)
}
